<?php $settings=DB::table('settings')->get(); ?>
<?php
$path="";    
?>
<?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 <?php
    $path=$data->logo
?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                 
<?php $__env->startSection('meta'); ?>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
    
	<meta property="og:url" content="https://www.facebook.com/alsaeedyblog">  
   


    <?php if(isset($channel)): ?>

            <meta name="description" content=" <?php echo e($videos->title); ?>  - السعدي">
            <meta property="og:type" content="article">
            <meta property="og:title" content=" <?php echo e($videos->{'title-ar'}); ?>   - السعدي"> 

            <meta name="og:image" content=" <?php echo e(url($videos->{'title-fr'})); ?>  - السعدي">
            <meta name="twitter:image" content=" <?php echo e(url($videos->{'title-fr'})); ?>  - السعدي">

            <meta name="twitter:description" content=" <?php echo e($videos->title); ?>  - السعدي">
            <meta name="keywords" content="<?php echo e(str_replace('-',',',strip_tags($videos->slug))); ?> ,السعدي, مقاطع فيديو,موسوعة,عربية,شاملة,فيديو">

            
            <meta property="og:description" content=" <?php echo e($videos->title); ?>  - السعدي">

            <?php $__env->startSection('title',$videos->title . " | السعدي "); ?> 
            
    <?php else: ?>
   
    
        <meta property="og:image"  itemprop="image"  content="<?php echo e(url('images/blog.jpg')); ?>" />
        <meta name="twitter:image" content="<?php echo e(url('images/blog.jpg')); ?>">
    
        
    
    
        <meta name="twitter:description" content="السعدي - مقاطع فيديو - أكبر موقع عربي بالعالم ">
    
        <meta name="keywords" content=" ,السعدي, مقاطع فيديو,موسوعة,عربية,شاملة">
        <meta name="description" content="السعدي - مقاطع فيديو - أكبر موقع عربي بالعالم">
        
        <meta property="og:type" content="article" />
        <meta property="og:title" content="السعدي - مقاطع فيديو - أكبر موقع عربي بالعالم"> 
        <meta property="og:description" content="السعدي - مقاطع فيديو - أكبر موقع عربي بالعالم">

<?php $__env->startSection('title',"السعدي - مقاطع فيديو - أكبر موقع عربي بالعالم"); ?> 
    <?php endif; ?>



	<meta name="keywords" content="<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>,<?php echo e($tag->title); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">


    <?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <!-- Breadcrumbs -->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="bread-inner">
                        <ul class="bread-list">
                            <li><a href="<?php echo e(route('home')); ?>"><?php echo e(Lang::get('msg.home')); ?><i class="ti-arrow-right"></i></a></li>
                            <li class="active"><a href="javascript:void(0);"><?php echo e(Lang::get('msg.video')); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumbs -->
        
    <!-- Start video Single -->
    <section class="blog-single shop-blog grid section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-12">
                    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5062667702348863"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:block; text-align:center;"
     data-ad-layout="in-article"
     data-ad-format="fluid"
     data-ad-client="ca-pub-5062667702348863"
     data-ad-slot="4854742754"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
                        <h3>فيديو</h3>
                    <div class="row">
                        <?php if(isset($channel)): ?>
                        <div class="col-12" style="font-size: 20px;">
                            <?php echo e($videos->{'title-ar'}); ?>

                        </div>
                            <?php
                                
                        $videos=$videos->video;
                            ?>
                        <?php else: ?>
                            <?php
                                
                        $videos=$videos;
                            ?>
                        <?php endif; ?>
                        
                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                      
	<?php
    $url = url($video->{'quote-ar'});
    parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars ); 
    if (isset($my_array_of_vars['v'])) {
    
        $ur=$my_array_of_vars['v'];
        $video_r_url=$video->{'quote-ar'};
    }else{
        $ur=explode("https://youtu.be/",$url)[1];
        $video_r_url="https://www.youtube.com/watch?v=".$ur;
    }
    
    
        ?>
                        
                            <div class="col-lg-6 col-md-6 col-12">
                                <!-- Start Single Blog  -->
                                <div class="shop-single-blog col-12">
                                <img src="https://i.ytimg.com/vi_webp/<?php echo e($ur); ?>/sddefault.webp" alt="<?php echo e($video->{'title-ar'}); ?>">
                                    <div class="content col-12">
                                        <?php 
                                            $author_info=DB::table('users')->select('name')->where('id',$video->added_by)->get();
                                        ?>
                                        <p class="date">
                                            <i class="fa fa-calendar" aria-hidden="true"> </i> 
                                            
                                            <?php echo e($video->created_at->format('d M, Y. D')); ?>

                                            <span class="float-right">
                                                <i class="fa fa-user" aria-hidden="true"></i> 
                                                <?php $__currentLoopData = $author_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($data->name): ?>
                                                        <?php echo e($data->name); ?>

                                                    <?php else: ?>
                                                    <?php echo e(Lang::get('msg.anonymous')); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </span>
                                        </p>
                                        <a href="<?php echo e(route('video.detail',$video->slug)); ?>" class="title"><?php echo e($video->{'title-ar'}); ?></a>
                                        
                                        <div> مشاهدات <i class="fa fa-eye"></i> <?php echo e(intval($video->{'description-fr'})); ?> </div>
                                        <p><?php echo html_entity_decode($video->{"summary-ar"} ); ?></p>

                                        <a href="<?php echo e(route('video.detail',$video->slug)); ?>" class="more-btn"><?php echo e(Lang::get('msg.continuereading')); ?></a>
                                    </div>
                                </div>
                                <!-- End Single video  -->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12">
                            <!-- Pagination -->
                            
                            <!--/ End Pagination -->
                        </div>
                    </div>
                </div>
                <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5062667702348863"
     crossorigin="anonymous"></script>
<!-- square -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-5062667702348863"
     data-ad-slot="6101495379"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5062667702348863"
     crossorigin="anonymous"></script>
<!-- respo -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-5062667702348863"
     data-ad-slot="2257736673"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
                <div class="col-lg-4 col-12">

                    <div class="main-sidebar">
                        <!-- Single Widget -->
                        <div class="single-widget search">
                            <form class="form" method="GET" action="<?php echo e(route('video.search')); ?>">
                                <input type="text" placeholder="<?php echo e(Lang::get('msg.search')); ?>" name="search">
                                <button class="button" type="sumbit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                        <!--/ End Single Widget -->
                        <!-- Single Widget -->
                        <div class="single-widget category">
                            <h3 class="title"><?php echo e(Lang::get('msg.videocategories')); ?></h3>
                            <ul class="categor-list">
                                <?php if(!empty($_GET['category'])): ?>
                                    <?php 
                                        $filter_cats=explode(',',$_GET['category']);
                                    ?>
                                <?php endif; ?>
                            <form action="<?php echo e(route('video.filter')); ?>" method="POST"> 
                                    <?php echo csrf_field(); ?>
                                    
                                    <?php $__currentLoopData = Helper::videoCategoryList('videos'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                    <li>
                                        <a href="<?php echo e(route('video.category',$cat->slug)); ?>"><?php echo e($cat->{'title-ar'}); ?> </a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </form>
                                
                            </ul>
                        </div>
                        <!--/ End Single Widget -->
                        <!-- Single Widget -->
                        <div class="single-widget recent-video"> 
                            <h3 class="title"><?php echo e(Lang::get('msg.recentvideo')); ?></h3>
                            <?php $__currentLoopData = $recent_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Single video -->
                                              
	<?php
    $url = url($video->{'quote-ar'});
    parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars ); 
    if (isset($my_array_of_vars['v'])) {
    
        $ur=$my_array_of_vars['v'];
        $video_r_url=$video->{'quote-ar'};
    }else{
        $ur=explode("https://youtu.be/",$url)[1];
        $video_r_url="https://www.youtube.com/watch?v=".$ur;
    }
    
    
        ?><a href="<?php echo route('video.detail',strip_tags($video->slug)); ?>">
                                <div class="single-video " style="
                                
                                    width: 100%;
    margin-bottom: 10px;
    padding: 10px;
    background: #f1f1f1;
                                
                                " >
                                        <img src="https://i.ytimg.com/vi_webp/<?php echo e($ur); ?>/sddefault.webp"  alt="<?php echo e($video->{'title-ar'}); ?>">
                                    
                                    <div class="content col-12" style="    padding: 10px 0;">
                                        
                                        <h5><?php echo e($video->{'title-ar'}); ?></h5>
                                        <?php echo $video->{'summary-ar'}; ?>

                                        <div> مشاهدات <i class="fa fa-eye"></i> <?php echo e(intval($video->{'description-fr'})); ?> </div>

                                        <p style="    margin-bottom: 0;">
                                        <?php 
                                            $author_info=DB::table('users')->select('name')->where('id',$video->added_by)->get();
                                        ?>
                                            <i class="fa fa-calendar" aria-hidden="true"></i>
                                            <?php echo e($video->created_at->format('d M, y')); ?> -
                                            <i class="fa fa-user" aria-hidden="true"></i> 
                                             <?php echo e($author_info[0]->name); ?>

                                    
                                        </p>

                                    </div>
                                </div>
                            </a>
                                <!-- End Single video -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!--/ End Single Widget -->
                        <!-- Single Widget -->
                        <!--/ End Single Widget -->
                        <!-- Single Widget -->
          
                        
                        <!--/ End Single Widget -->
                        <!-- Single Widget -->
                        <div class="single-widget newsletter">
                            <h3 class="title"><?php echo e(Lang::get('msg.newslatter')); ?></h3>
                            <div class="letter-inner">
                                <h4><?php echo e(Lang::get('msg.subscribetogetnews')); ?></h4>
                                
                            </div>
                        </div>
                        <!--/ End Single Widget -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End video Single -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <style>
        .pagination{
            display:inline-flex;
        }
    </style>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/frontend/pages/video.blade.php ENDPATH**/ ?>