                                                
<?php $__env->startSection('meta'); ?>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
	<meta property="og:url" content="<?php echo url('/about-us'); ?>"> 

	<meta name="keywords" content=" مدونة,السعدي,مدونة السعدي ,مقالات ,عنا">
	<meta name="description" content="مدونة السعدي - عنا">
	
    
	<meta property="og:type" content="article">
	<meta property="og:title" content="مدونة السعدي - عنا">
	<meta property="og:image"  itemprop="image"  content="<?php echo e(url('images/blog.jpg')); ?>">
    <meta name="twitter:image" content="<?php echo e(url('images/blog.jpg')); ?>">
	<meta property="og:description" content="مدونة السعدي - عنا">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title',"عنا - السعدي"); ?>

<?php $__env->startSection('main-content'); ?>

	<!-- Breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>عنا</h2>
					<div class="bread-inner">
						<ul class="bread-list">
							<li><a href="index1.html"><?php echo Lang::get('msg.home'); ?><i class="ti-arrow-right"></i></a></li>
							<li class="active"><a href="/">عنا</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Breadcrumbs -->
	
	<!-- About Us -->
	<section class="about-us section">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-12">
						<div class="about-content">
							<?php
								$settings=DB::table('settings')->get();
							?>
							<h3>مدونة السعدي  <span> عنا</span></h3>
							<p><?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $data->description; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
							<div class="button">
								<a href="<?php echo e(route('blog')); ?>" class="btn"><?php echo Lang::get('msg.ourblog'); ?></a>
								<a href="<?php echo e(route('contact')); ?>" class="btn primary"><?php echo Lang::get('msg.contactus'); ?></a>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-12">
						<div class="about-img overlay">
							<div class="button">
								<a href="https://www.youtube.com/watch?v=x2faZxiUaeI&list=PL5YQQjbl8yGqf6P5dWH8ltDzvnkRi9UEu"  class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
							<img src="<?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($data->photo); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" alt="السعدي">
						</div>
					</div>
				</div>
			</div>
	</section>
	<!-- End About Us -->
	
	<!-- Start Team -->
	
	<!--/ End Team Area -->
	

	
	
	<?php echo $__env->make('frontend.layouts.newsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/frontend/pages/about-us.blade.php ENDPATH**/ ?>