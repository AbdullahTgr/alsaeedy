 


<?php $__env->startSection('title',"Lang::get('msg.Alsaidi')"); ?>
<?php $__env->startSection('main-content'); ?>
<div class="container-fluid"> 
    <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
      <h1 class="h3 mb-0 text-gray-800">النقرات</h1>
    </div>

    <div class="card shadow mb-4">
      <div class="row">
          <div class="col-md-12">
             <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
      </div>

      
     <div class="card-body">



<?php if(isset($sp)): ?>
    <?php echo $__env->make('backend.sp_country', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php echo $__env->make('backend.countries', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>



 
<?php echo $__env->make('frontend.videopar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
 <?php echo $__env->make('frontend.hotposts_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>












    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/backend/visito.blade.php ENDPATH**/ ?>