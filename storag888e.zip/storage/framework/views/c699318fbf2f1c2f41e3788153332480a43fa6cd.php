<?php $__env->startSection('title',"اتفاقية الاستخدام"); ?>
<?php
								$settings=DB::table('settings')->get();
							?>
<?php $__env->startSection('main-content'); ?>
    <!-- Breadcrumbs -->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="bread-inner">
                        <ul class="bread-list">
                            <li><a href="<?php echo e(route('home')); ?>"><?php echo e(Lang::get('msg.home')); ?><i class="ti-arrow-right"></i></a></li>
                            <li class="active"><a href="javascript:void(0);">اتفاقية الاستخدام</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumbs -->
<section class="tracking_box_area section_gap py-5">
    <div class="container">
        <?php echo $settings[0]->termsandconditions; ?>    
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/frontend/pages/policy.blade.php ENDPATH**/ ?>