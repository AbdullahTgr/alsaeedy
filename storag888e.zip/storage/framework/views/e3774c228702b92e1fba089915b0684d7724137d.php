
       <div class="table-responsive">
        <table class="table table-bordered" id="click-dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
                <th>country</th>
                <th>ip</th>
                <th>po4</th>
                <th>po4</th>
                <th>browser</th>
                <th>governrate</th>
                <th>city</th>
                <th>post code</th>
                <th>lat</th>
                <th>long</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
             <th>البلد</th>
             <th>عدد الزيارات</th>
              </tr>
          </tfoot> 
          <tbody>

           
            <?php $__currentLoopData = $clicks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $click): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <tr>
                 <?php
                     if($click->prop5==null){
                       $country="No";
                     }else{
                       $country=$click->prop5;
                     }
                 ?>
                   <td><a href="<?php echo e(route('visito_s',$country)); ?>"><?php echo e($country); ?></a></td>
                 
                   <td><?php echo e($click->prop1); ?></td>
                   <td><?php echo e($click->prop2); ?></td>
                   <td><?php echo e($click->prop3); ?></td>
                   <td><?php echo e($click->prop4); ?></td>
                   <td><?php echo e($click->prop6); ?></td>
                   <td><?php echo e($click->prop7); ?></td>
                   <td><?php echo e($click->prop8); ?></td>
                   <td><?php echo e($click->prop9); ?></td>
                   <td><?php echo e($click->prop10); ?></td>

            
                   
                 
                </tr>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




          </tbody>
        </table>
        
      </div>
    </div>
</div>


<?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/backend/sp_country.blade.php ENDPATH**/ ?>