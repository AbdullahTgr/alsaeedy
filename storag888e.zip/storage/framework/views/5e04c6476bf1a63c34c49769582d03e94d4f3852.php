









<section class="content-item grey" id="blog-timeline">
	<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5062667702348863"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:block; text-align:center;"
     data-ad-layout="in-article"
     data-ad-format="fluid"
     data-ad-client="ca-pub-5062667702348863"
     data-ad-slot="4854742754"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
        <div class="container" style="
    padding-top: 15px;
		">





            <div class="row">
				
             
                <!-- BLOG POSTS - START -->
                <div class="col-sm-10">
                  <h2>مقالات</h2>
                    <div class="timeline">
                        <?php if($news): ?>
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if($post->postcat[0]->{'title-ar'}!="اخبار"): ?>
									 
                        <?php echo e($post->postcat[0]->{'title-ar'}); ?>

						
							<?php 
								$author_info=DB::table('users')->where('id',$post->added_by)->get();
							?>
<div><i class="fa fa-eye"></i> <?php echo e(intval($post->{'description-fr'})); ?> </div>
 

								<i class="fa fa-calendar" aria-hidden="true"></i>
								<a href="<?php echo e(route('blog.detail',$post->slug)); ?>" style="padding: 14px;
									font-size: 13px;
									font-weight: bold;">
								<?php echo e($post->created_at->format('d M, y')); ?>

								
</a>
								
									
							
									
     <!-- BLOG POST 1 - START -->
     <div class="blog-post">
					<?php $__currentLoopData = $author_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="blog-info">

            <img src="<?php echo e($data->photo); ?>" class="img-responsive"  alt="<?php echo e($data->{'name'}); ?>">
		
	
			<div class="date">
				
					<?php if($data->name): ?>
						<?php echo e($data->name); ?>

					<?php else: ?>
					<?php echo e(Lang::get('msg.anonymous')); ?> 
					<?php endif; ?>
				
			</div>
          </div>
 
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  
          <h2><a href="<?php echo e(route('blog.detail',$post->slug)); ?>"><?php echo $post->{'title-ar'}; ?> </a></h2>
          <div class="date-xs"> <?php echo e($post->created_at->format('d M , Y. D')); ?></div>

          <p>
			<a href="<?php echo e(route('blog.detail',$post->slug)); ?>" style="padding: 14px;
				font-size: 13px; 
				font-weight: bold;">
<?php
$arr=explode("/",$post->photo);
$arrcount=count($arr);
$newpath="/";

?>

<?php for($i = 1; $i < $arrcount; $i++): ?>

	<?php
	if($i==$arrcount-1){
		$newpath.='thumbs/'.$arr[$i];
	}else{
		$newpath.=$arr[$i]."/";
	}
		
	?>
	
<?php endfor; ?>



			<img class="img-responsive pull-right" src="<?php echo e($newpath); ?>"  alt="<?php echo e($post->{'title-ar'}); ?>"><?php echo $post->{'summary-ar'}; ?>

</a>
		 </p>

		  
      </div>
      <!-- BLOG POST 1 - END --> 
								 
									 
								 <?php endif; ?>



                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                 
                        
                        
                    </div>
                    
                    <div class="text-center">
                      <a href="##" class="btn btn-danger btn-lg">Load More</a>
                    </div>
                    
                </div>
                <!-- BLOG POSTS - END --> 
                
                <!-- SIDEBAR - START -->
                <div class="col-sm-2" style="direction: rtl;">
					<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5062667702348863"
     crossorigin="anonymous"></script>
<!-- square -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-5062667702348863"
     data-ad-slot="6101495379"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
					<div class="sidebar"> 
						  <h3>فئات</h3>
						  <div class="box categories">
							  <ul class="list-unstyled">
								  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									  <li><a href="<?php echo e(route('blog.category',$category->{'slug'})); ?>"><i class="fa fa-female"></i><?php echo e($category->{'title-ar'}); ?></a></li>
								  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								  
							  </ul>
						  </div>
						  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5062667702348863"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:block; text-align:center;"
     data-ad-layout="in-article"
     data-ad-format="fluid"
     data-ad-client="ca-pub-5062667702348863"
     data-ad-slot="4854742754"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
						  
					  </div>
				  </div>
				  <!-- SIDEBAR - END -->
        
				  
            </div>
        </div>
    </section><?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/frontend/collection.blade.php ENDPATH**/ ?>