
<section>

    <div class="container">
        <h2 style="
        padding: 18px;
    text-align: center;
        ">اكثر قراءة</h2>
        <div class="row" >
    
     
            <?php $__currentLoopData = $hotposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


     <!-- SIDEBAR - START -->
    <div class="col-sm-4 col-lg-3" >
        <div class="sidebar">
                
                <div class="box categories box_rr">
                    <ul class="list-unstyled">

                    <li>
                        <?php echo e($post->postcat[0]->{'title-ar'}); ?>

                        <a href=""><h3> <?php echo $post->{'title-ar'}; ?></h3></a></li>
                        <div><i class="fa fa-eye"></i> <?php echo e(intval($post->{'description-fr'})); ?> </div>
                        <a href="<?php echo e(route('blog.detail',$post->slug)); ?>" style="padding: 14px;
                            font-size: 13px;
                            font-weight: bold;">
                        <img class="img-responsive pull-right" width="100%;" src="<?php echo e($post->photo); ?>"  alt="<?php echo e($post->{'title-ar'}); ?>">
            </a>
                        <li><a href="<?php echo e(route('post.visitors',$post->id)); ?>"><i class="fa fa-fire"></i>عرض المشاهدات</a></li>
                     
                    </ul>
                </div>
        </div> 
    </div> 
    <!-- SIDEBAR - END -->       
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    
    
    
    
    
    
    
    
    
        </div>
    </div>

</section><?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/frontend/hotposts_admin.blade.php ENDPATH**/ ?>