
       <div class="table-responsive">
        <table class="table table-bordered" id="click-dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
             <th>البلد</th>
             <th>عدد الزيارات</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
             <th>البلد</th>
             <th>عدد الزيارات</th>
              </tr>
          </tfoot>
          <tbody>
 
           
            <?php $__currentLoopData = $clicks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $click): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <tr>
                 <?php
                     if($click->prop5==null){
                       $country="No";
                     }else{
                       $country=$click->prop5;
                     }
                 ?>

                 <?php if(isset($post_id)): ?>
                 <td><a href="<?php echo e(route('visito_s',$country.",".$post_id)); ?>"><?php echo e($country); ?></a></td>
                 <?php else: ?>
                     <td><a href="<?php echo e(route('visito_s',$country)); ?>"><?php echo e($country); ?></a></td>
                 <?php endif; ?>
                   
                 
                   <td><?php echo e($click->total); ?></td>
                 
                </tr>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




          </tbody>
        </table>
        
      </div>
    </div>
</div>


<?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/backend/countries.blade.php ENDPATH**/ ?>