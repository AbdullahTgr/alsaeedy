<?php $__env->startSection('style'); ?>
<style>


.box_rr{
    border: 1px solid #ddd;
    box-shadow: 1px 1px 12px #e9e9e9;
    
}
</style>

<?php $__env->stopSection(); ?>

<div class="container">
    <div class="row" style="direction: rtl;">


        <?php $__currentLoopData = $maincatroot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <!-- SIDEBAR - START -->
<div class="col-sm-3" >
    <div class="sidebar">
            
            <div class="box categories box_rr">
                <ul class="list-unstyled">
                <li><a href=""><h3><?php echo e($category->{'title-ar'}); ?></h3></a></li>
                    <?php $__currentLoopData = $category->maincategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('video.maincategory',$cat->{'slug'})); ?>"><i class="fa fa-female"></i><?php echo e($cat->{'title-ar'}); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    
                </ul>
            </div>
    </div> 
</div> 
<!-- SIDEBAR - END -->       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




    </div>
</div>

















<?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/frontend/videocategories.blade.php ENDPATH**/ ?>