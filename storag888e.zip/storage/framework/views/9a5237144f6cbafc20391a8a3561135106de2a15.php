<header class="header shop">

    
    <div class="middle-inner">
        
<?php if(session()->get('locale')=="ar" || session()->get('locale')=="" ): ?>
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/arabic.css')); ?>">
<?php endif; ?>
            <style>



.abdullahmostafa{
    background: #dddddd;
    padding: 2px 10px 15px 10px;
    transition: all 1s ease-out;
}

.abdullahmostafa nav label{
    background: linear-gradient(45deg, #a7a7a7, #000000);
    color: white;
    padding: 3px 15px;
    border-radius: 5px;
    margin: 0;
    margin-left: 3px;
    margin-top: 13px;
    transition: all 1s ease-out;
}

.abdullahmostafa nav label:hover{
    background: linear-gradient(45deg, #f38792, #0f93ff);
    color: white;
    position: relative;
    border-radius: 5px;
    margin: 0;
    font-weight: bold;
    margin-left: 3px;
    top: -3px;
}
label{
    transition: all 1s ease-out;
}



            </style>
        

        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-2 col-12">
                    <!-- Logo -->
                    <div class="logo">
                       
                    </div>
                    <!--/ End Logo --> 
              
                    
                    <!--/ End Search Form -->
                    <div class="mobile-nav"></div>
                </div>

                
                <div class="col-lg-2 col-md-3 col-12">
              
                    
                </div>
            </div>
        </div>
    </div>
    <!-- Header Inner -->
    <div class="header-inner">
        <div class="container">
            <div class="cat-nav-head">
                <div class="row">
                    <div class="col-lg-12 col-12">
                        <div class="menu-area">
                            <!-- Main Menu -->
                            <nav class="navbar navbar-expand-lg">
                                <div class="navbar-collapse">	
                                    <div class="nav-inner" 
                                    <?php if(session()->get('locale')=="ar"): ?> style="direction: rtl" <?php endif; ?>>	
                                    <ul class="nav main-menu menu navbar-nav">
                                        <li class="<?php echo e(Request::path()=='home' ? 'active' : ''); ?>"><a href="<?php echo e(route('home')); ?>"><?php echo e(Lang::get('msg.home')); ?></a></li>
                                        <li class="<?php echo e(Request::path()=='about-us' ? 'active' : ''); ?>"><a href="<?php echo e(route('about-us')); ?>"><?php echo e(Lang::get('msg.aboutus')); ?></a></li>
                                        
                                            <li class="<?php echo e(Request::path()=='blog' ? 'active' : ''); ?>"><a href="<?php echo e(route('blog')); ?>"><?php echo e(Lang::get('msg.blog')); ?></a></li>	

                                            
                                            <li class="<?php echo e(Request::path()=='writers' ? 'active' : ''); ?>"><a href="<?php echo e(route('writers')); ?>"><?php echo e(Lang::get('msg.writers')); ?></a></li>
                                          
                                            
                                            
                                        <li class="<?php echo e(Request::path()=='contact' ? 'active' : ''); ?>"><a href="<?php echo e(route('contact')); ?>"><?php echo e(Lang::get('msg.contactus')); ?></a></li>
                                    
                                        <?php
                        $settings=DB::table('settings')->get();
                        
                    ?>           
                    
                    <li class="pull-left" style="
                        position: absolute;
left: 0;
                    "><a href="<?php echo e(route('home')); ?>" style="padding:0;"><img width="50px" src="<?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($data->logo); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" alt="السعدي"></a> </li>         
                    
                                    </ul>


                                   








                                    
                                    </div>
                                </div>
                            </nav>
                            <!--/ End Main Menu -->	
                             
                                     

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ End Header Inner -->
</header>
       <?php echo e(Helper::getHeaderCategory('فئات' )); ?>   
                        
<?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/frontend/layouts/header.blade.php ENDPATH**/ ?>