
                                                 

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
    
	<meta property="og:url" content="https://www.facebook.com/alsaeedyblog"> 
    <meta property="og:image"  itemprop="image"  content="<?php echo e(url('images/blog.jpg')); ?>" />
    <meta name="twitter:image" content="<?php echo e(url('images/blog.jpg')); ?>">

    


    <meta name="twitter:description" content=" السعدي - هنئ اصدقائك بعيد الاضحي ">

	<meta name="keywords" content="موسوعة,عربية,شاملة,السعدي">
	<meta name="description" content=" السعدي  - هنئ اصدقائك بعيد الاضحي">
	
    <meta property="og:type" content="article" />
	<meta property="og:title" content=" السعدي  - هنئ اصدقائك بعيد الاضحي"> 
	<meta property="og:description" content=" السعدي  - هنئ اصدقائك بعيد الاضحي">

    
<title>السعدي  - اكتب اسم من تحب تهنئتة بعيد الاضحي</title>
<style>
    
    /* Global ------------------------------------------------------ */

html {
  overflow: hidden; /*FF fix*/
  height: 100%;
  font-family: Geneva, sans-serif;
  background: hsl(210, 30%, 0%) radial-gradient( hsl(210, 30%, 20%), hsl(210, 30%, 0%));
}

body {
  margin: 0;
  width: 100%;
  height: 100%;
  text-align: center;
  
  display: flex;
  justify-content: center;
  align-items: center;
}

p {
    margin: 0;
}


/* box ------------------------------------------------------ */

#box {
    padding: 115px 67px;
    text-align: center;
    min-width: 500px;
    font-size: 60px;
    font-weight: bold;
    -webkit-backface-visibility: hidden;
}


/* flashlight ------------------------------------------------------ */

#flashlight {
  color: hsla(0,0%,0%,0);
  perspective: 80px;
  outline: none;
}


/* flash ------------------------------------------------------ */

#flash {
  display: inline-block;
  text-shadow: #bbb 0 0 1px, #fff 0 -1px 2px, #fff 0 -3px 2px, rgba(0,0,0,0.8) 0 30px 25px;
  transition: margin-left 0.3s cubic-bezier(0, 1, 0, 1);
}
    
#box:hover #flash {
  margin-left: 20px;
  transition: margin-left 1s cubic-bezier(0, 0.75, 0, 1);
}


/* light ------------------------------------------------------ */

#light {
  display: inline-block;
  text-shadow: #111 0 0 1px, rgba(255,255,255,0.1) 0 1px 3px;
}

#box:hover #light {
  text-shadow: #fff 0 0 4px, #fcffbb 0 0 20px;
  transform: rotateY(-60deg);
  transition:         transform 0.3s cubic-bezier(0, 0.75, 0, 1), text-shadow 0.1s ease-out;
}












@import  url(https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js);
@import  url(https://fonts.googleapis.com/css?family=Arvo);
/* iconicfill */
[class*="iconicfill-"]:before {
  font-family: 'IconicFill', sans-serif;
}

body,html{width:100%;height:100%;}
body{font-family:'Arvo'; background: #4f3b5b;background: -moz-radial-gradient(center, ellipse cover,  #4f3b5b 0%, #231733 100%);background: -webkit-gradient(radial, center center, 0px, center center, 100%, color-stop(0%,#4f3b5b), color-stop(100%,#231733));background: -webkit-radial-gradient(center, ellipse cover,  #4f3b5b 0%,#231733 100%);background: -o-radial-gradient(center, ellipse cover,  #4f3b5b 0%,#231733 100%);background: -ms-radial-gradient(center, ellipse cover,  #4f3b5b 0%,#231733 100%);background: radial-gradient(ellipse at center,  #4f3b5b 0%,#231733 100%);}

.wrap{width:300px;}
.center{
 top:50%;
 transform:translateY(-50%);
 position:relative;
 margin:auto;}

input{
    display: block;
    width: 100%;
    height: 103px;
    padding: 15px 0 15px 12px;
    font-family: "Arvo";
    font-weight: 400;
    color: #377D6A;
    background: rgba(0,0,0,0.3);
    border: none;
    outline: none;
    color: #fff;
    text-shadow: 1px 1px 1px rgb(0 0 0 / 30%);
    border: 1px solid rgba(0,0,0,0.3);
    border-radius: 4px;
    box-shadow: inset 0 -5px 45px rgb(100 100 100 / 20%), 0 1px 1px rgb(255 255 255 / 20%);
    text-indent: 60px;
    transition: all .3s ease-in-out;
    position: relative;
    font-size: 52px;
}
input:focus{
    text-indent: 12px;
    box-shadow: inset 0 -5px 45px rgba(100,100,100,0.4), 0 1px 1px rgba(255,255,255,0.2);
}

label{
    display: block;
    position: static;
    margin: 0;
    padding: 0;
    color:#fff;
    font-family: 'Arvo';
    font-size: 50px;
}

.wrap-label{
    width: 100%;
    height: 100px;
    position: relative;
    padding: 0;
    margin: 0;
    bottom: 0px;
    overflow: hidden;
}

.iconicfill-pen-alt2{
    position: absolute;
    left: 10px;
    color: #fff;
    font-size:19px;
    opacity: 1;
    top: -2px;
    transform:translateX(-100px);
}

/* ==== Pen animation ==== */
.move-pen{animation: move-pen 1s ease-in infinite alternate;}
@keyframes  move-pen{
    from{transform:translateX(-4px) rotate(6deg);}
    to{transform:translateX(4px) rotate(-3deg);}
}
    </style>










<section>
    <div id="box">
        <p id="flashlight">
          <span id="flash">صديقك</span>
          <span id="light">هنئ</span>
        </p>
      </div>



     


<form class="form-contact form contact_form" method="post" action="<?php echo e(route('eid_name')); ?>" id="contactForm" novalidate="novalidate">
    <?php echo csrf_field(); ?>
 <div class="wrap center"> <!-- Just to center ver and hor -->
        <div class="wrap-label">
           <label for="name">الاسم</label>
           <p class="iconicfill-pen-alt2"><i class="fas fa-pencil-alt"></i></p>
        </div>
        <input type="text" id="name" name="name">
      </div>
</form>
</section>
   








<script>

  // jquery transit is used to handle the animation
  $('input').focusin(function() {
        $('label').transition({x:'80px'},500,'ease').next()
        .transition({x:'5px'},500, 'ease');
//setTimeout needed for Chrome, for some reson there is no animation from left to right, the pen is immediately present. Slight delay to adding the animation class fixes it
         setTimeout(function(){
		    $('label').next().addClass('move-pen');
	      },100);
		
		});
		  
		  $('input').focusout(function() {
          $('label').transition({x:'0px'},500,'ease').next()
           .transition({x:'-100px'},500, 'ease').removeClass('move-pen');
		  });


</script><?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/frontend/pages/eid.blade.php ENDPATH**/ ?>