
<?php 
                                                        $tags=explode(',',$post->tags);
                                                    ?>
                                                    
<?php $__env->startSection('meta'); ?>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name='copyright' content=''>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
	<meta property="og:url" content="<?php echo route('blog.detail',strip_tags($post->slug)); ?>"> 

	<meta name="keywords" content="<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>,<?php echo e($tag); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
	<meta name="description" content="<?php echo strip_tags( $post->{'quote'} ); ?>">
	
    
	<meta property="og:type" content="article">
	<meta property="og:title" content="<?php echo strip_tags($post->{'title'}); ?>">
	<meta property="og:image" content="<?php echo e($post->photo); ?> ">
	<meta property="og:description" content="<?php echo strip_tags($post->{'description'} ); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title',strip_tags($post->{'title'})); ?>

<?php $__env->startSection('main-content'); ?>
    <!-- Breadcrumbs -->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="bread-inner">
                        <ul class="bread-list">
                            <li><a href="<?php echo e(route('home')); ?>"><?php echo e(Lang::get('msg.home')); ?><i class="ti-arrow-right"></i></a></li>
                            <li class="active"><a href="javascript:void(0);"><?php echo e(Lang::get('msg.blog')); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumbs -->
        
    <!-- Start Blog Single -->
    <section class="blog-single section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-12">
                    <div class="blog-single-main">
                        <div class="row">
                            <div class="col-12">
                                <div class="image">
                                    <img src="<?php echo e($post->photo); ?>" alt="<?php echo e($post->photo); ?>">
                                </div>
                                <div class="blog-detail">
                                    <h2 class="blog-title"><?php echo e($post->title); ?></h2>
                                    <div class="blog-meta">
                                        <span class="author"><a href="javascript:void(0);"><i class="fa fa-user"></i><?php echo e(Lang::get('msg.by')); ?> <?php echo e($post->author_info['name']); ?></a><a href="javascript:void(0);"><i class="fa fa-calendar"></i><?php echo e($post->created_at->format('M d, Y')); ?></a><a href="javascript:void(0);"><i class="fa fa-comments"></i><?php echo e(Lang::get('msg.comment')); ?> (<?php echo e($post->allComments->count()); ?>)</a></span>
                                    </div>
                                    <div class="sharethis-inline-reaction-buttons"></div>
                                    <div class="sharethis-inline-share-buttons"></div>
                                    <div class="content">
                                        <?php if($post->quote): ?>
                                        <blockquote> <i class="fa fa-quote-left"></i> <?php echo ($post->quote); ?></blockquote>
                                        <?php endif; ?>
                                        <p><?php echo ($post->description); ?></p>
                                    </div>
                                </div>
                                <div class="share-social">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="content-tags">
                                                <h4><?php echo e(Lang::get('msg.tag')); ?>:</h4>
                                                <ul class="tag-inner">
                                                    <?php 
                                                        $tags=explode(',',$post->tags);
                                                    ?>
                                                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="javascript:void(0);"><?php echo e($tag); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php if(auth()->guard()->check()): ?>
                            <div class="col-12 mt-4">			
                                <div class="reply">
                                    <div class="reply-head comment-form" id="commentFormContainer">
                                        <h2 class="reply-title"><?php echo e(Lang::get('msg.leaveacomment')); ?></h2>
                                        <!-- Comment Form -->
                                        <form class="form comment_form" id="commentForm" action="<?php echo e(route('post-comment.store',$post->slug)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                
                                                <div class="col-12">
                                                    <div class="form-group  comment_form_body">
                                                        <label><?php echo e(Lang::get('msg.yourmessage')); ?><span>*</span></label>
                                                        <textarea name="comment" id="comment" rows="10" placeholder=""></textarea>
                                                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>" />
                                                        <input type="hidden" name="parent_id" id="parent_id" value="" />
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-group button">
                                                        <button type="submit" class="btn"><span class="comment_btn comment"><?php echo e(Lang::get('msg.postcomment')); ?></span><span class="comment_btn reply" style="display: none;"><?php echo e(Lang::get('msg.replaycomment')); ?></span></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                        <!-- End Comment Form -->
                                    </div>
                                </div>			
                            </div>
                            	
                            <?php else: ?> 
                            <p class="text-center p-5">
                                <?php echo e(Lang::get('msg.youneedto')); ?><a href="<?php echo e(route('login.form')); ?>" style="color:rgb(54, 54, 204)"><?php echo e(Lang::get('msg.login')); ?></a> <?php echo e(Lang::get('msg.or')); ?> <a style="color:blue" href="<?php echo e(route('register.form')); ?>"><?php echo e(Lang::get('msg.register')); ?></a> <?php echo e(Lang::get('msg.forcomment')); ?> 

                            </p>

                           
                            <!--/ End Form -->
                            <?php endif; ?>										
                            <div class="col-12">
                                <div class="comments">
                                    <h3 class="comment-title"> <?php echo e(Lang::get('msg.comments')); ?> (<?php echo e($post->allComments->count()); ?>)</h3>
                                    <!-- Single Comment -->
                                    <?php echo $__env->make('frontend.pages.comment', ['comments' => $post->comments, 'post_id' => $post->id, 'depth' => 3], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <!-- End Single Comment -->
                                </div>									
                            </div>	
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-12">
                    <div class="main-sidebar">
                        <!-- Single Widget -->
                        <div class="single-widget search">
                            <form class="form" method="GET" action="<?php echo e(route('blog.search')); ?>">
                                <input type="text" placeholder="Search Here..." name="search">
                                <button class="button" type="sumbit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                        <!--/ End Single Widget -->
                        <!-- Single Widget -->
                        



                        <!--/ End Single Widget -->
                        <!-- Single Widget -->
                        <div class="single-widget recent-post">
                            <h3 class="title"><?php echo e(Lang::get('msg.recentpost')); ?></h3>
                            <?php $__currentLoopData = $recent_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Single Post -->
                                <div class="single-post">
                                    <div class="image">
                                        <img src="<?php echo e($post->photo); ?>" alt="<?php echo e($post->photo); ?>">
                                    </div>
                                    <div class="content">
                                        <h5><a href="#"><?php echo e($post->title); ?></a></h5>
                                        <ul class="comment">
                                        <?php 
                                            $author_info=DB::table('users')->select('name')->where('id',$post->added_by)->get();
                                        ?>
                                            <li><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e($post->created_at->format('d M, y')); ?></li>
                                            <li><i class="fa fa-user" aria-hidden="true"></i> 
                                                <?php $__currentLoopData = $author_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($data->name): ?>
                                                        <?php echo e($data->name); ?>

                                                    <?php else: ?>
                                                    <?php echo e(Lang::get('msg.anonymous')); ?> 
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- End Single Post -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!--/ End Single Widget -->
                        <!-- Single Widget -->
                        <!--/ End Single Widget -->
                        <!-- Single Widget -->
                        <div class="single-widget side-tags">
                            <h3 class="title"><?php echo e(Lang::get('msg.tags')); ?></h3>
                            <ul class="tag">
                                <?php $__currentLoopData = Helper::postTagList('posts'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href=""><?php echo e($tag->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!--/ End Single Widget -->
                        <!-- Single Widget -->
                        <div class="single-widget newsletter">
                            <h3 class="title"><?php echo e(Lang::get('msg.newslatter')); ?></h3>
                            <div class="letter-inner">
                                <h4><?php echo e(Lang::get('msg.subscribetogetnews')); ?> </h4>
                                
                            </div>
                        </div>
                        <!--/ End Single Widget -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Blog Single -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=5f2e5abf393162001291e431&product=inline-share-buttons' async='async'></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function(){
    
    (function($) {
        "use strict";

        $('.btn-reply.reply').click(function(e){
            e.preventDefault();
            $('.btn-reply.reply').show();

            $('.comment_btn.comment').hide();
            $('.comment_btn.reply').show();

            $(this).hide();
            $('.btn-reply.cancel').hide();
            $(this).siblings('.btn-reply.cancel').show();

            var parent_id = $(this).data('id');
            var html = $('#commentForm');
            $( html).find('#parent_id').val(parent_id);
            $('#commentFormContainer').hide();
            $(this).parents('.comment-list').append(html).fadeIn('slow').addClass('appended');
          });  

        $('.comment-list').on('click','.btn-reply.cancel',function(e){
            e.preventDefault();
            $(this).hide();
            $('.btn-reply.reply').show();

            $('.comment_btn.reply').hide();
            $('.comment_btn.comment').show();

            $('#commentFormContainer').show();
            var html = $('#commentForm');
            $( html).find('#parent_id').val('');

            $('#commentFormContainer').append(html);
        });
        
 })(jQuery)
})
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saadyy\alsaeedy\resources\views/frontend/pages-en/blog-detail.blade.php ENDPATH**/ ?>