
<div class="row">
    <?php $__currentLoopData = $product_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php 
                                $photo=explode(',',$product->photo);
                            // dd($photo);
                            ?>
    <div class="col-lg-4 col-md-6 text-center <?php echo e($product->cat_id); ?>">
        <div class="single-product-item">
            <div class="product-image">
                <a href="<?php echo e(route('product-detail',$product->slug)); ?>"><img src="<?php echo e($photo[0]); ?>" alt="<?php echo e($photo[0]); ?>"></a>
            </div>
            <h3>
                            
                            
                <?php if(session()->get('locale')=="en"): ?>
                    
                <?php echo e($product->title); ?>

                <?php elseif(session()->get('locale')=="fr"): ?>
                    
                <?php echo e($product->{'title-fr'}); ?>

                <?php else: ?>
                    
                <?php echo e($product->{'title-ar'}); ?>

                <?php endif; ?>
              </h3>
            
            <p class="product-price">
                <span>
                    <a data-toggle="modal" data-target="#<?php echo e($product->id); ?>" title="Quick View" href="#"><i class=" ti-eye"></i><span><?php echo e(Lang::get('msg.quickshop')); ?></span></a>
             </span>
            
                <?php
                $after_discount=($product->price-($product->price*$product->discount)/100);
            ?>
            <span><del style="padding-left:4%;">L.E <?php echo e(number_format($product->price,2)); ?></del></span>
            L.E <?php echo e(number_format($after_discount,2)); ?>

            
            </p>
            <a class="cart-btn" href="<?php echo e(route('add-to-cart',$product->slug)); ?>"><?php echo e(Lang::get('msg.addtocart')); ?><i class="fa fa-shopping-cart"></i></a>
        </div>
    </div>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH /home2/ieisco23/alsaeedy.com/resources/views/frontend/newprd.blade.php ENDPATH**/ ?>